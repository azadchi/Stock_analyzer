# -*- coding: utf-8 -*-
"""market_data.py — دریافت دیتای واقعی OHLCV نماد از TSETMC (از طریق algotik-tse)
به‌جای حدس زدن اعداد از روی عکس چارت.

نکته: TSETMC یک API رسمی عمومی ندارد؛ این ماژول از کتابخانه‌ی متن‌باز algotik-tse
استفاده می‌کند که با وب‌اسکرپینگ ساختاریافته داده را از همان سایت می‌گیرد (دقیقاً
همان کاری که مرورگر شما انجام می‌دهد). به همین دلیل ممکن است گاهی کند یا خطا بدهد؛
این ماژول این حالت را با خطای قابل‌فهم مدیریت می‌کند تا بقیه‌ی برنامه کرش نکند.
"""
import pandas as pd


class MarketDataError(Exception):
    """خطای قابل‌نمایش به کاربر هنگام ناموفق بودن دریافت یا پردازش داده‌ی بازار."""


TIMEFRAME_INTRADAY = {"60 دقیقه": "60min", "15 دقیقه": "15min"}
TIMEFRAME_RESAMPLE = {"هفتگی": "W", "ماهانه": "ME"}


def _standardize_columns(df):
    df = df.copy()
    df.columns = [str(c).strip().title() for c in df.columns]
    required = {"Open", "High", "Low", "Close", "Volume"}
    missing = required - set(df.columns)
    if missing:
        raise MarketDataError(
            "ستون‌های مورد نیاز در داده‌ی دریافتی از TSETMC نبود: " + "، ".join(sorted(missing))
        )
    for col in ("Open", "High", "Low", "Close", "Volume"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df.dropna(subset=["Open", "High", "Low", "Close"])


def fetch_ohlcv(symbol, timeframe, limit=300):
    """دیتای OHLCV واقعی نماد را برای تایم‌فریم مشخص برمی‌گرداند (DataFrame با
    ستون‌های Open/High/Low/Close/Volume، مرتب از قدیم به جدید)."""
    try:
        import algotik_tse as tse
    except ImportError:
        raise MarketDataError(
            "کتابخانه‌ی algotik-tse نصب نیست. دستور نصب: pip install algotik-tse"
        )

    symbol = (symbol or "").strip()
    if not symbol:
        raise MarketDataError("نام نماد خالی است.")

    try:
        if timeframe in TIMEFRAME_INTRADAY:
            df = tse.get_intraday(symbol, interval=TIMEFRAME_INTRADAY[timeframe], progress=False)
        else:
            df = tse.get_history(
                symbol,
                limit=max(limit, 260),
                output_type="standard",
                date_format="gregorian",
                auto_adjust=True,
                progress=False,
            )
    except Exception as exc:  # کتابخانه‌های اسکرپر خطاهای متنوعی می‌دهند
        raise MarketDataError(
            "دریافت اطلاعات نماد «%s» از TSETMC ناموفق بود (%s). ممکن است سایت موقتاً "
            "کند/در دسترس نباشد، یا نام نماد دقیق نباشد." % (symbol, exc)
        )

    if df is None or len(df) == 0:
        raise MarketDataError(
            "داده‌ای برای نماد «%s» یافت نشد. نام نماد باید دقیقاً مطابق نام رسمی "
            "در TSETMC باشد (مثلاً «شبندر» نه «شبندر سهام»)." % symbol
        )

    df = _standardize_columns(df)

    if timeframe in TIMEFRAME_RESAMPLE:
        if not isinstance(df.index, pd.DatetimeIndex):
            df.index = pd.to_datetime(df.index, errors="coerce")
        df = df[df.index.notna()]
        agg = {"Open": "first", "High": "max", "Low": "min", "Close": "last", "Volume": "sum"}
        df = df.resample(TIMEFRAME_RESAMPLE[timeframe]).agg(agg).dropna()

    if len(df) < 30:
        raise MarketDataError(
            "داده‌ی کافی برای محاسبه‌ی اندیکاتورها موجود نیست (فقط %d ردیف). "
            "تایم‌فریم دیگری (مثلاً روزانه) را امتحان کن." % len(df)
        )

    return df.tail(limit).reset_index(drop=True)
